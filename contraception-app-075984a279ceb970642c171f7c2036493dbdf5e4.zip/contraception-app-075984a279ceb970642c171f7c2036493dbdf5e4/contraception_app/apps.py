from django.apps import AppConfig


class ContraceptionAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'contraception_app'
